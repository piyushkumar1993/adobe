/**
*@author: Piyush
*main configuration file
*/

(function(){
	angular.module("main_module",["indian_recipes_module","ngRoute"]);
	angular.module("main_module").config(function($routeProvider,$locationProvider){
		$routeProvider
		.when("/",{
			"template":"<h1 style='text-align:center'>Welcome to the Recipes App</h1>"
		})
		.when("/indian",{
			"templateUrl":"app/pages/indianRecipes.html"

		})
	}).run(check);

	function check($rootScope, $location,  $http) {
		$rootScope.$on('$locationChangeStart', function (event, next, current) {
			var loc=$location.path();
           //console.log(loc);
           loc=loc.substring(1);
           $(".menu li").removeClass("active")
           $(".menu li:first").addClass("active");

           if(loc!=""){
           	$(".menu li").removeClass("active")
           $(".menu a[name="+loc+"] ").parent().addClass("active");
       }
		});
	}
})();