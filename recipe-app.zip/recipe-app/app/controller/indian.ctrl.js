/**
*@author: Piyush
*Indian recipes module
*/
(function(){
	angular.module("indian_recipes_module",["indian_service_module"]);

	/**
	*	Controller for viewing Indian Recipes
	*/
	angular.module("indian_recipes_module").controller("IndianRecipesController",function($rootScope,$scope,IndianRecipesService){

		$scope.recipes=[];
		$scope.curRecipe=[];
		$scope.curRecipeDishes=[];
		$scope.curIngredients=[];
		$scope.showIngredients=false;
		$scope.curDish=[];

		/**
		*	Fetching recipes from the server
		*/
		IndianRecipesService.getRecipes().then(function(data){
			$scope.recipes=data.data;
			
		},
		function(data){

		});

		
		/**
		*	Viewing dishes on the page
		*/
		$scope.viewDishes=function(event){

			$rootScope.$broadcast("view_dishes_event",event.target.id);//notify
		}
		

		

		
	});


	/**
	*	Controller for viewing Indian Dishes
	*/
	angular.module("indian_recipes_module").controller("IndianDishesController",function($scope,$rootScope,IndianRecipesService){
		

		$scope.$on("view_dishes_event",function(evt,recipeId){
				console.log("ff")
				IndianRecipesService.getDishes(recipeId).then(function(data){
				$scope.curDishes=data.data;
				// console.log($scope.curRecipe)
				// $scope.curRecipeDishes=$scope.curRecipe.dishes;
				// $scope.curRecipeId=$scope.curRecipe.id;
				
			},
			function(data){

			});
			
		})

		$scope.viewIngredients=function(event){

			// $scope.curRecipeDishes.forEach(function(dish){
			// 	if(dish.id==event.target.id)
			// 		$scope.curDishId=dish.id;
			// 		$scope.curDish=dish;
			// 		$scope.curIngredients=dish.ingredients;
			// })
			$rootScope.$broadcast("view_ingredients_event",event.target.id);
			// $scope.curDishId=event.target.id;
			// IndianRecipesService.getIngredients(event.target.id).then(function(data){
			// 	$scope.curIngredients=data.data;
			// },function(data){

			// })
			// $scope.showIngredients=true;
			//console.log($scope.curIngredients);
		}
		
		
	});


	/**
	*	Controller for viewing Indian Ingredients
	*/
	angular.module("indian_recipes_module").controller("IndianIngredientsController",function($scope,$rootScope,IndianRecipesService){


		$scope.$on("view_ingredients_event",function(evt,dishId){
		$scope.curDishId=event.target.id;
			IndianRecipesService.getIngredients(event.target.id).then(function(data){
				$scope.curIngredients=data.data;
			},function(data){

			})
			$scope.showIngredients=true;
		});
		$scope.addIngredient=function(){
			
			var newIngredient={};
			newIngredient.name=$scope.ingredientToAdd;
			newIngredient.dishId=$scope.curDishId;

			IndianRecipesService.addIngredient(newIngredient);
			$scope.curIngredients.push(newIngredient);

			//IndianRecipesService.addRecipe(recipe);
			$("#addIngredient").val("");
			//console.log(recipe);
		}
	})
})();