/**
*@author: Piyush
*Service to fetch and store Indian Recipes
*/
(function() {
	angular.module("indian_service_module",[]);
	angular.module("indian_service_module").service("IndianRecipesService",function($http,$q){
		

		this.getRecipes=function(){
			var deferred=$q.defer();
			$http.get("/recipes").then(function(data){
				deferred.resolve(data);
			},
			function(){
				deferred.reject(data);
			});
			return deferred.promise;
		}


		this.getDishes=function(recipeId){
			var deferred=$q.defer();

			$http.get("/dishes?recipeId="+recipeId).then(function(data){
				deferred.resolve(data);
			},
			function(){
				deferred.reject(data);
			});
			return deferred.promise;
		}

		this.getIngredients=function(dishId){
			var deferred=$q.defer();
			
			$http.get("/ingredients?dishId="+dishId).then(function(data){
				deferred.resolve(data);
			},
			function(){
				deferred.reject(data);
			});
			return deferred.promise;
		}

		this.addIngredient=function(ingredient){
			$http.post("/ingredients",ingredient);
		}

		
	});
})();